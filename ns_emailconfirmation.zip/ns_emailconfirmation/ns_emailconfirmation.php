<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

class Ns_EmailConfirmation extends Module
{
    public function __construct()
    {
        $this->name = 'ns_emailconfirmation';
        $this->tab = 'administration';
        $this->version = '1.0.0';
        $this->author = 'NdiagaSoft';
        $this->need_instance = 0;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Email Confirmation on User Creation');
        $this->description = $this->l('Sends an email confirmation to a user when created in the back office.');
    }

    public function install()
    {
        return parent::install() && $this->registerHook('actionObjectCustomerAddAfter');
    }

    public function uninstall()
    {
        return parent::uninstall();
    }
	
	public function getContent()
    {
        $output = '';
       
		$output.='<br/>'.$this->display(__FILE__, 'advertizement.tpl');
		

        return $output;
		
    }

    public function hookActionObjectCustomerAddAfter($params)
    {
        $customer = $params['object'];

        if ($customer instanceof Customer && $customer->id) {
            $this->sendConfirmationEmail($customer);
        }
    }

    private function sendConfirmationEmail(Customer $customer)
    {
        $templateVars = array(
            '{firstname}' => $customer->firstname,
            '{lastname}' => $customer->lastname,
            '{email}' => $customer->email,
        );

        Mail::Send(
            (int)$this->context->language->id,
            'account',
            $this->l('Welcome to Our Store!'),
            $templateVars,
            $customer->email,
            $customer->firstname . ' ' . $customer->lastname,
            null,
            null,
            null,
            null,
            _PS_MAIL_DIR_,
            false,
            $this->context->shop->id
        );
    }
}
